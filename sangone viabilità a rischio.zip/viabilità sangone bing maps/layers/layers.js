var baseLayer = new ol.layer.Group({
    'title': 'Base maps',
    layers: [
new ol.layer.Tile({
    'title': 'Thunderforest Outdoors',
    'type': 'base',
    source: new ol.source.XYZ({
        url: 'http://tile.thunderforest.com/outdoors/{z}/{x}/{y}.png',
        attributions: [new ol.Attribution({html: '&copy; <a href="http://www.opencyclemap.org">OpenCycleMap</a>,&copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors,<a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>'})]
    })
}),
new ol.layer.Tile({
    'title': 'Stamen Terrain',
    'type': 'base',
    source: new ol.source.Stamen({
        layer: 'terrain'
    })
}),
new ol.layer.Tile({
    'title': 'Aerial Bing Maps',
    'type': 'base',
            source: new ol.source.BingMaps({
              imagerySet: 'AerialWithLabels',
              key: 'ApYT-CBycwXBzNArfXES6AfdkE_BpSWnFpyTy0kCVmCEbQjkCSAyXvkxCsnfYjY_'
     })
})
]
});
var format_bacinoSangone0 = new ol.format.GeoJSON();
var features_bacinoSangone0 = format_bacinoSangone0.readFeatures(json_bacinoSangone0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_bacinoSangone0 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_bacinoSangone0.addFeatures(features_bacinoSangone0);var lyr_bacinoSangone0 = new ol.layer.Vector({
                source:jsonSource_bacinoSangone0, 
                style: style_bacinoSangone0,
                title: '<img src="styles/legend/bacinoSangone0.png" /> bacino Sangone'
            });var format_Comunidelcontratto1 = new ol.format.GeoJSON();
var features_Comunidelcontratto1 = format_Comunidelcontratto1.readFeatures(json_Comunidelcontratto1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Comunidelcontratto1 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_Comunidelcontratto1.addFeatures(features_Comunidelcontratto1);var lyr_Comunidelcontratto1 = new ol.layer.Vector({
                source:jsonSource_Comunidelcontratto1, 
                style: style_Comunidelcontratto1,
                title: '<img src="styles/legend/Comunidelcontratto1.png" /> Comuni del contratto'
            });var format_scenarioalluvione100200vsdefanni2 = new ol.format.GeoJSON();
var features_scenarioalluvione100200vsdefanni2 = format_scenarioalluvione100200vsdefanni2.readFeatures(json_scenarioalluvione100200vsdefanni2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_scenarioalluvione100200vsdefanni2 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_scenarioalluvione100200vsdefanni2.addFeatures(features_scenarioalluvione100200vsdefanni2);var lyr_scenarioalluvione100200vsdefanni2 = new ol.layer.Vector({
                source:jsonSource_scenarioalluvione100200vsdefanni2, 
                style: style_scenarioalluvione100200vsdefanni2,
                title: '<img src="styles/legend/scenarioalluvione100200vsdefanni2.png" /> scenario alluvione 100-200 vsdef anni'
            });var format_scenarioareeallagabiliperiodo1025anni3 = new ol.format.GeoJSON();
var features_scenarioareeallagabiliperiodo1025anni3 = format_scenarioareeallagabiliperiodo1025anni3.readFeatures(json_scenarioareeallagabiliperiodo1025anni3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_scenarioareeallagabiliperiodo1025anni3 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_scenarioareeallagabiliperiodo1025anni3.addFeatures(features_scenarioareeallagabiliperiodo1025anni3);var lyr_scenarioareeallagabiliperiodo1025anni3 = new ol.layer.Vector({
                source:jsonSource_scenarioareeallagabiliperiodo1025anni3, 
                style: style_scenarioareeallagabiliperiodo1025anni3,
                title: '<img src="styles/legend/scenarioareeallagabiliperiodo1025anni3.png" /> scenario aree allagabili periodo 10-25 anni'
            });var format_puntidipresidiodaattivare4 = new ol.format.GeoJSON();
var features_puntidipresidiodaattivare4 = format_puntidipresidiodaattivare4.readFeatures(json_puntidipresidiodaattivare4, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_puntidipresidiodaattivare4 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_puntidipresidiodaattivare4.addFeatures(features_puntidipresidiodaattivare4);var lyr_puntidipresidiodaattivare4 = new ol.layer.Vector({
                source:jsonSource_puntidipresidiodaattivare4, 
                style: style_puntidipresidiodaattivare4,
                title: '<img src="styles/legend/puntidipresidiodaattivare4.png" /> punti di presidio da attivare'
            });var format_Sangonescenariorischioviabilit5 = new ol.format.GeoJSON();
var features_Sangonescenariorischioviabilit5 = format_Sangonescenariorischioviabilit5.readFeatures(json_Sangonescenariorischioviabilit5, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Sangonescenariorischioviabilit5 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_Sangonescenariorischioviabilit5.addFeatures(features_Sangonescenariorischioviabilit5);var lyr_Sangonescenariorischioviabilit5 = new ol.layer.Vector({
                source:jsonSource_Sangonescenariorischioviabilit5,
minResolution:0.000280044661523,
 maxResolution:19.6034063512,

                style: style_Sangonescenariorischioviabilit5,
                title: 'Sangone scenario rischio viabilità<br />\
        <img src="styles/legend/Sangonescenariorischioviabilit5_0.png" /> R3 - Rischio elevato<br />\
        <img src="styles/legend/Sangonescenariorischioviabilit5_1.png" /> R4 - Rischio molto elevato<br />'
            });var format_attraversamentolineeelettrichesangone6 = new ol.format.GeoJSON();
var features_attraversamentolineeelettrichesangone6 = format_attraversamentolineeelettrichesangone6.readFeatures(json_attraversamentolineeelettrichesangone6, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_attraversamentolineeelettrichesangone6 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_attraversamentolineeelettrichesangone6.addFeatures(features_attraversamentolineeelettrichesangone6);var lyr_attraversamentolineeelettrichesangone6 = new ol.layer.Vector({
                source:jsonSource_attraversamentolineeelettrichesangone6, 
                style: style_attraversamentolineeelettrichesangone6,
                title: '<img src="styles/legend/attraversamentolineeelettrichesangone6.png" /> attraversamento linee elettriche sangone'
            });var format_impiantisemaforiciSangone7 = new ol.format.GeoJSON();
var features_impiantisemaforiciSangone7 = format_impiantisemaforiciSangone7.readFeatures(json_impiantisemaforiciSangone7, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_impiantisemaforiciSangone7 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_impiantisemaforiciSangone7.addFeatures(features_impiantisemaforiciSangone7);var lyr_impiantisemaforiciSangone7 = new ol.layer.Vector({
                source:jsonSource_impiantisemaforiciSangone7,
minResolution:0.280044661523,
 maxResolution:16.8026796914,

                style: style_impiantisemaforiciSangone7,
                title: '<img src="styles/legend/impiantisemaforiciSangone7.png" /> impianti semaforici Sangone'
            });

lyr_bacinoSangone0.setVisible(true);lyr_Comunidelcontratto1.setVisible(true);lyr_scenarioalluvione100200vsdefanni2.setVisible(true);lyr_scenarioareeallagabiliperiodo1025anni3.setVisible(true);lyr_puntidipresidiodaattivare4.setVisible(true);lyr_Sangonescenariorischioviabilit5.setVisible(true);lyr_attraversamentolineeelettrichesangone6.setVisible(false);lyr_impiantisemaforiciSangone7.setVisible(false);
var layersList = [baseLayer,lyr_bacinoSangone0,lyr_Comunidelcontratto1,lyr_scenarioalluvione100200vsdefanni2,lyr_scenarioareeallagabiliperiodo1025anni3,lyr_puntidipresidiodaattivare4,lyr_Sangonescenariorischioviabilit5,lyr_attraversamentolineeelettrichesangone6,lyr_impiantisemaforiciSangone7];
lyr_bacinoSangone0.set('fieldAliases', {'NOME': 'NOME', });
lyr_Comunidelcontratto1.set('fieldAliases', {'comune_top': 'comune_top', 'istat_num': 'istat_num', });
lyr_scenarioalluvione100200vsdefanni2.set('fieldAliases', {'CODSCENAR': 'Scenario', 'T_RITORNO': 'T_RITORNO', 'BACINO': 'BACINO', 'STATISTICA': 'STATISTICA', });
lyr_scenarioareeallagabiliperiodo1025anni3.set('fieldAliases', {'SCENARIO': 'SCENARIO', });
lyr_puntidipresidiodaattivare4.set('fieldAliases', {'id': 'id', 'azioni_ATT': 'azioni_ATT', 'Azioni_PRE': 'Azioni_PRE', 'azioni_ALL': 'azioni_ALL', 'attuatore': 'attuatore', });
lyr_Sangonescenariorischioviabilit5.set('fieldAliases', {'gid2': 'Identificativo', 'catit': 'catit', 'catdist': 'catdist', 'danno': 'Classe del danno', 'denorig': 'Denominazione originale', 'numabit': 'numabit', 'codscen': 'Codice scenario', 'ris': 'Codice della classe di rischio', 'lunghezza': 'Lunghezza in metri', });
lyr_attraversamentolineeelettrichesangone6.set('fieldAliases', {'ogc_fid': 'ogc_fid', 'id_evento': 'id_evento', 'x': 'x', 'y': 'y', 'autorizzaz': 'autorizzaz', 'centroabit': 'centroabit', 'descrizion': 'descrizion', 'pr1': 'pr1', 'pr2': 'pr2', 'pa1': 'pa1', 'pa2': 'pa2', 'x1': 'x1', 'y1': 'y1', 'z1': 'z1', 'x2': 'x2', 'y2': 'y2', 'z2': 'z2', 'dataaggior': 'dataaggior', 'storico': 'storico', 'elemento': 'elemento', 'strada': 'strada', });
lyr_impiantisemaforiciSangone7.set('fieldAliases', {'ogc_fid': 'ogc_fid', 'id_evento': 'id_evento', 'x': 'x', 'y': 'y', 'alimentazi': 'alimentazi', 'nlanterne': 'nlanterne', 'supalo': 'supalo', 'supalina': 'supalina', 'sospese': 'sospese', 'nfasisemaf': 'nfasisemaf', 'tipocentra': 'tipocentra', 'entepropri': 'entepropri', 'del_comuna': 'del_comuna', 'num_del_pr': 'num_del_pr', 'annodel_pr': 'annodel_pr', 'datainstal': 'datainstal', 'datacollau': 'datacollau', 'nomecollau': 'nomecollau', 'costoimpia': 'costoimpia', 'dataverbal': 'dataverbal', 'costoannuo': 'costoannuo', 'datainizio': 'datainizio', 'codiceprog': 'codiceprog', 'puntodicon': 'puntodicon', 'codicecont': 'codicecont', 'tipoarmadi': 'tipoarmadi', 'interrutto': 'interrutto', 'datariliev': 'datariliev', 'note': 'note', 'descrizion': 'descrizion', 'pr1': 'pr1', 'pr2': 'pr2', 'pa1': 'pa1', 'pa2': 'pa2', 'x1': 'x1', 'y1': 'y1', 'z1': 'z1', 'x2': 'x2', 'y2': 'y2', 'z2': 'z2', 'dataaggior': 'dataaggior', 'storico': 'storico', 'elemento': 'elemento', 'strada': 'strada', });
lyr_bacinoSangone0.set('fieldImages', {'NOME': 'TextEdit', });
lyr_Comunidelcontratto1.set('fieldImages', {'comune_top': 'TextEdit', 'istat_num': 'TextEdit', });
lyr_scenarioalluvione100200vsdefanni2.set('fieldImages', {'CODSCENAR': 'TextEdit', 'T_RITORNO': 'TextEdit', 'BACINO': 'TextEdit', 'STATISTICA': 'TextEdit', });
lyr_scenarioareeallagabiliperiodo1025anni3.set('fieldImages', {'SCENARIO': 'TextEdit', });
lyr_puntidipresidiodaattivare4.set('fieldImages', {'id': 'TextEdit', 'azioni_ATT': 'TextEdit', 'Azioni_PRE': 'TextEdit', 'azioni_ALL': 'TextEdit', 'attuatore': 'TextEdit', });
lyr_Sangonescenariorischioviabilit5.set('fieldImages', {'gid2': 'TextEdit', 'catit': 'TextEdit', 'catdist': 'TextEdit', 'danno': 'TextEdit', 'denorig': 'TextEdit', 'numabit': 'TextEdit', 'codscen': 'TextEdit', 'ris': 'TextEdit', 'lunghezza': 'TextEdit', });
lyr_attraversamentolineeelettrichesangone6.set('fieldImages', {'ogc_fid': 'TextEdit', 'id_evento': 'TextEdit', 'x': 'TextEdit', 'y': 'TextEdit', 'autorizzaz': 'TextEdit', 'centroabit': 'TextEdit', 'descrizion': 'TextEdit', 'pr1': 'TextEdit', 'pr2': 'TextEdit', 'pa1': 'TextEdit', 'pa2': 'TextEdit', 'x1': 'TextEdit', 'y1': 'TextEdit', 'z1': 'TextEdit', 'x2': 'TextEdit', 'y2': 'TextEdit', 'z2': 'TextEdit', 'dataaggior': 'TextEdit', 'storico': 'TextEdit', 'elemento': 'TextEdit', 'strada': 'TextEdit', });
lyr_impiantisemaforiciSangone7.set('fieldImages', {'ogc_fid': 'TextEdit', 'id_evento': 'TextEdit', 'x': 'TextEdit', 'y': 'TextEdit', 'alimentazi': 'TextEdit', 'nlanterne': 'TextEdit', 'supalo': 'TextEdit', 'supalina': 'TextEdit', 'sospese': 'TextEdit', 'nfasisemaf': 'TextEdit', 'tipocentra': 'TextEdit', 'entepropri': 'TextEdit', 'del_comuna': 'TextEdit', 'num_del_pr': 'TextEdit', 'annodel_pr': 'TextEdit', 'datainstal': 'TextEdit', 'datacollau': 'TextEdit', 'nomecollau': 'TextEdit', 'costoimpia': 'TextEdit', 'dataverbal': 'TextEdit', 'costoannuo': 'TextEdit', 'datainizio': 'TextEdit', 'codiceprog': 'TextEdit', 'puntodicon': 'TextEdit', 'codicecont': 'TextEdit', 'tipoarmadi': 'TextEdit', 'interrutto': 'TextEdit', 'datariliev': 'TextEdit', 'note': 'TextEdit', 'descrizion': 'TextEdit', 'pr1': 'TextEdit', 'pr2': 'TextEdit', 'pa1': 'TextEdit', 'pa2': 'TextEdit', 'x1': 'TextEdit', 'y1': 'TextEdit', 'z1': 'TextEdit', 'x2': 'TextEdit', 'y2': 'TextEdit', 'z2': 'TextEdit', 'dataaggior': 'TextEdit', 'storico': 'TextEdit', 'elemento': 'TextEdit', 'strada': 'TextEdit', });
lyr_bacinoSangone0.set('fieldLabels', {'NOME': 'no label', });
lyr_Comunidelcontratto1.set('fieldLabels', {'comune_top': 'inline label', 'istat_num': 'inline label', });
lyr_scenarioalluvione100200vsdefanni2.set('fieldLabels', {'CODSCENAR': 'inline label', 'T_RITORNO': 'inline label', 'BACINO': 'inline label', 'STATISTICA': 'inline label', });
lyr_scenarioareeallagabiliperiodo1025anni3.set('fieldLabels', {'SCENARIO': 'inline label', });
lyr_puntidipresidiodaattivare4.set('fieldLabels', {'id': 'inline label', 'azioni_ATT': 'inline label', 'Azioni_PRE': 'inline label', 'azioni_ALL': 'inline label', 'attuatore': 'inline label', });
lyr_Sangonescenariorischioviabilit5.set('fieldLabels', {'gid2': 'no label', 'catit': 'no label', 'catdist': 'no label', 'danno': 'no label', 'denorig': 'no label', 'numabit': 'no label', 'codscen': 'no label', 'ris': 'no label', 'lunghezza': 'no label', });
lyr_attraversamentolineeelettrichesangone6.set('fieldLabels', {'ogc_fid': 'no label', 'id_evento': 'no label', 'x': 'no label', 'y': 'no label', 'autorizzaz': 'no label', 'centroabit': 'no label', 'descrizion': 'no label', 'pr1': 'no label', 'pr2': 'no label', 'pa1': 'no label', 'pa2': 'no label', 'x1': 'no label', 'y1': 'no label', 'z1': 'no label', 'x2': 'no label', 'y2': 'no label', 'z2': 'no label', 'dataaggior': 'no label', 'storico': 'no label', 'elemento': 'no label', 'strada': 'no label', });
lyr_impiantisemaforiciSangone7.set('fieldLabels', {'ogc_fid': 'no label', 'id_evento': 'no label', 'x': 'no label', 'y': 'no label', 'alimentazi': 'no label', 'nlanterne': 'no label', 'supalo': 'no label', 'supalina': 'no label', 'sospese': 'no label', 'nfasisemaf': 'no label', 'tipocentra': 'no label', 'entepropri': 'no label', 'del_comuna': 'no label', 'num_del_pr': 'no label', 'annodel_pr': 'no label', 'datainstal': 'no label', 'datacollau': 'no label', 'nomecollau': 'no label', 'costoimpia': 'no label', 'dataverbal': 'no label', 'costoannuo': 'no label', 'datainizio': 'no label', 'codiceprog': 'no label', 'puntodicon': 'no label', 'codicecont': 'no label', 'tipoarmadi': 'no label', 'interrutto': 'no label', 'datariliev': 'no label', 'note': 'no label', 'descrizion': 'no label', 'pr1': 'no label', 'pr2': 'no label', 'pa1': 'no label', 'pa2': 'no label', 'x1': 'no label', 'y1': 'no label', 'z1': 'no label', 'x2': 'no label', 'y2': 'no label', 'z2': 'no label', 'dataaggior': 'no label', 'storico': 'no label', 'elemento': 'no label', 'strada': 'no label', });
lyr_impiantisemaforiciSangone7.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});
