var size = 0;

var styleCache_scenarioalluvione100200vsdefanni2={}
var style_scenarioalluvione100200vsdefanni2 = function(feature, resolution){
    var context = {
        feature: feature,
        variables: {}
    };
    var value = ""
    var labelText = "";
    var key = "";
    size = 0;
    var textAlign = "left";
    var offsetX = 8;
    var offsetY = 3;
    if ("" !== null) {
        labelText = String("");
    } else {
        labelText = ""
    }
    var style = [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(31,131,224,0.2)', lineDash: null, lineCap: 'butt', lineJoin: 'miter', width: 0}), fill: new ol.style.Fill({color: 'rgba(31,159,224,0.2)'})
    })];
    key = value + "_" + labelText
    if (!styleCache_scenarioalluvione100200vsdefanni2[key]){
        var text = new ol.style.Text({
                font: '10.725px \'Noto Sans\', sans-serif',
                text: labelText,
                textBaseline: "middle",
                textAlign: textAlign,
                offsetX: offsetX,
                offsetY: offsetY,
                fill: new ol.style.Fill({
                  color: 'rgba(0, 0, 0, 1)'
                })
            });
        styleCache_scenarioalluvione100200vsdefanni2[key] = new ol.style.Style({"text": text})
    }
    var allStyles = [styleCache_scenarioalluvione100200vsdefanni2[key]];
    allStyles.push.apply(allStyles, style);
    return allStyles;
};