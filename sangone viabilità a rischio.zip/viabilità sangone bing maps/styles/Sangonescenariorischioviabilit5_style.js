var size = 0;
function categories_Sangonescenariorischioviabilit5(feature, value, size) {
                switch(value) {case 'R3':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(211,255,0,0.69)', lineDash: null, lineCap: 'round', lineJoin: 'round', width: 7}),
    })];
                    break;
case 'R4':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(170,0,255,0.69)', lineDash: null, lineCap: 'round', lineJoin: 'round', width: 7}),
    })];
                    break;}};
var styleCache_Sangonescenariorischioviabilit5={}
var style_Sangonescenariorischioviabilit5 = function(feature, resolution){
    var context = {
        feature: feature,
        variables: {}
    };
    var value = feature.get("ris");
    var labelText = "";
    var key = "";
    size = 0;
    var textAlign = "left";
    var offsetX = 8;
    var offsetY = 3;
    if ("" !== null) {
        labelText = String("");
    } else {
        labelText = ""
    }
    var style = categories_Sangonescenariorischioviabilit5(feature, value, size);
    key = value + "_" + labelText
    if (!styleCache_Sangonescenariorischioviabilit5[key]){
        var text = new ol.style.Text({
                font: '10.725px \'Noto Sans\', sans-serif',
                text: labelText,
                textBaseline: "middle",
                textAlign: textAlign,
                offsetX: offsetX,
                offsetY: offsetY,
                fill: new ol.style.Fill({
                  color: 'rgba(0, 0, 0, 1)'
                })
            });
        styleCache_Sangonescenariorischioviabilit5[key] = new ol.style.Style({"text": text})
    }
    var allStyles = [styleCache_Sangonescenariorischioviabilit5[key]];
    allStyles.push.apply(allStyles, style);
    return allStyles;
};