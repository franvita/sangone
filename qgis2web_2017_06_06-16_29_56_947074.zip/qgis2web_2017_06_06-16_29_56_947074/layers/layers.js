var baseLayer = new ol.layer.Group({
    'title': 'Base maps',
    layers: [
new ol.layer.Tile({
    'title': 'OSM',
    'type': 'base',
    source: new ol.source.OSM()
}),
new ol.layer.Tile({
    'title': 'Thunderforest Landscape',
    'type': 'base',
    source: new ol.source.XYZ({
        url: 'http://tile.thunderforest.com/landscape/{z}/{x}/{y}.png',
        attributions: [new ol.Attribution({html: '&copy; <a href="http://www.opencyclemap.org">OpenCycleMap</a>,&copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors,<a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>'})]
    })
}),
new ol.layer.Tile({
    'title': 'Stamen Terrain',
    'type': 'base',
    source: new ol.source.Stamen({
        layer: 'terrain'
    })
})
]
});
var format_COAZZEPERICOLOSIT0 = new ol.format.GeoJSON();
var features_COAZZEPERICOLOSIT0 = format_COAZZEPERICOLOSIT0.readFeatures(geojson_COAZZEPERICOLOSIT0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_COAZZEPERICOLOSIT0 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_COAZZEPERICOLOSIT0.addFeatures(features_COAZZEPERICOLOSIT0);var lyr_COAZZEPERICOLOSIT0 = new ol.layer.Vector({
                source:jsonSource_COAZZEPERICOLOSIT0, 
                style: style_COAZZEPERICOLOSIT0,
                title: "COAZZE PERICOLOSITÀ"
            });var format_COAZZERISCHIOAREE1 = new ol.format.GeoJSON();
var features_COAZZERISCHIOAREE1 = format_COAZZERISCHIOAREE1.readFeatures(geojson_COAZZERISCHIOAREE1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_COAZZERISCHIOAREE1 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_COAZZERISCHIOAREE1.addFeatures(features_COAZZERISCHIOAREE1);var lyr_COAZZERISCHIOAREE1 = new ol.layer.Vector({
                source:jsonSource_COAZZERISCHIOAREE1, 
                style: style_COAZZERISCHIOAREE1,
                title: "COAZZE RISCHIO AREE"
            });

lyr_COAZZEPERICOLOSIT0.setVisible(true);lyr_COAZZERISCHIOAREE1.setVisible(false);
var layersList = [baseLayer,lyr_COAZZEPERICOLOSIT0,lyr_COAZZERISCHIOAREE1];
lyr_COAZZEPERICOLOSIT0.set('fieldAliases', {'id_0': 'id_0', 'codarea': 'codarea', 'ambitoter': 'Ambito territoriale', 'nomeelidr': 'nomeelidr', 'codelidr': 'codelidr', 'nomebac': 'nomebac', 'codbac': 'codbac', 'nomebacs': 'nomebacs', 'codbacs': 'codbacs', 'codscenar': 'Scenario', 'datacons': 'datacons', 'tritorno': 'tritorno', 'ambitoamm': 'Ambito amministrativo', 'area': 'area', 'area_km2': 'area_km2', 'id': 'id', 'tipfenom': 'tipfenom', 'articolo6': 'articolo6', });
lyr_COAZZERISCHIOAREE1.set('fieldAliases', {'gid2': 'Identificativo', 'regione': 'Regione', 'risorsa': 'Fonte di origine del dato', 'atteconom': 'Tipologia attività economica', 'consamb': 'Tipologia elementi ambientali', 'cultpaes': 'Tipologia beni culturali e paesaggistici', 'catit': 'Categoria italiana', 'catdist': 'Categoria distretto', 'danno': 'Classe del danno
', 'propdato': 'Proprietario del dato', 'codorig': 'Codice di origine', 'denorig': 'Denominazione originale', 'annoril': 'Anno rilievo del dato', 'risspaz': 'Scala di riferimento', 'prov': 'Provincia', 'codcom': 'Codice istat comune
', 'catue': 'Categoria europea', 'numabit': 'Stima numero abitanti', 'ambter': 'Ambito territoriale', 'codscen': 'Codice scenario di alluvione', 'nomeelidr': 'Nome elemento idrico
', 'codelidr': 'Codice dell'elemento idrico', 'nomebac': 'Denominazione del bacino principale', 'nomebacs': 'Nome bacino di riferimento', 'codbacs': 'Codice bacino di riferimento', 'codarea': 'Codice area', 'codbac': 'Codice bacino principale', 'ris': 'Codice della classe di rischio', 'area': 'Superficie in metri quadrati', });
lyr_COAZZEPERICOLOSIT0.set('fieldImages', {'id_0': 'TextEdit', 'codarea': 'Hidden', 'ambitoter': 'TextEdit', 'nomeelidr': 'Hidden', 'codelidr': 'Hidden', 'nomebac': 'TextEdit', 'codbac': 'TextEdit', 'nomebacs': 'TextEdit', 'codbacs': 'TextEdit', 'codscenar': 'TextEdit', 'datacons': 'Hidden', 'tritorno': 'Hidden', 'ambitoamm': 'TextEdit', 'area': 'Hidden', 'area_km2': 'TextEdit', 'id': 'TextEdit', 'tipfenom': 'TextEdit', 'articolo6': 'TextEdit', });
lyr_COAZZERISCHIOAREE1.set('fieldImages', {'gid2': 'TextEdit', 'regione': 'TextEdit', 'risorsa': 'TextEdit', 'atteconom': 'TextEdit', 'consamb': 'TextEdit', 'cultpaes': 'TextEdit', 'catit': 'TextEdit', 'catdist': 'TextEdit', 'danno': 'TextEdit', 'propdato': 'TextEdit', 'codorig': 'TextEdit', 'denorig': 'TextEdit', 'annoril': 'TextEdit', 'risspaz': 'TextEdit', 'prov': 'TextEdit', 'codcom': 'TextEdit', 'catue': 'TextEdit', 'numabit': 'TextEdit', 'ambter': 'TextEdit', 'codscen': 'TextEdit', 'nomeelidr': 'TextEdit', 'codelidr': 'TextEdit', 'nomebac': 'TextEdit', 'nomebacs': 'TextEdit', 'codbacs': 'TextEdit', 'codarea': 'TextEdit', 'codbac': 'TextEdit', 'ris': 'TextEdit', 'area': 'TextEdit', });
lyr_COAZZEPERICOLOSIT0.set('fieldLabels', {'id_0': 'header label', 'ambitoter': 'inline label', 'nomebac': 'inline label', 'codbac': 'inline label', 'nomebacs': 'inline label', 'codbacs': 'inline label', 'codscenar': 'header label', 'ambitoamm': 'inline label', 'area_km2': 'inline label', 'id': 'inline label', 'tipfenom': 'no label', 'articolo6': 'inline label', });
lyr_COAZZERISCHIOAREE1.set('fieldLabels', {'gid2': 'inline label', 'regione': 'inline label', 'risorsa': 'inline label', 'atteconom': 'inline label', 'consamb': 'inline label', 'cultpaes': 'inline label', 'catit': 'inline label', 'catdist': 'inline label', 'danno': 'inline label', 'propdato': 'inline label', 'codorig': 'inline label', 'denorig': 'inline label', 'annoril': 'inline label', 'risspaz': 'inline label', 'prov': 'inline label', 'codcom': 'header label', 'catue': 'inline label', 'numabit': 'inline label', 'ambter': 'inline label', 'codscen': 'header label', 'nomeelidr': 'inline label', 'codelidr': 'inline label', 'nomebac': 'inline label', 'nomebacs': 'inline label', 'codbacs': 'inline label', 'codarea': 'inline label', 'codbac': 'header label', 'ris': 'header label', 'area': 'inline label', });
lyr_COAZZERISCHIOAREE1.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});