var size = 0;

var styleCache_COAZZEPERICOLOSIT0={}
var style_COAZZEPERICOLOSIT0 = {
            /* Traceback (most recent call last):
  File "/home/cernia/.qgis2/python/plugins/qgis2web/olwriter.py", line 901, in exportStyles
    name = compile_to_file(exp, name, "OpenLayers3", expFile)
  File "/home/cernia/.qgis2/python/plugins/qgis2web/exp2js.py", line 263, in compile_to_file
    functionjs, name, _ = compile(exp, name=name, mapLib=mapLib)
  File "/home/cernia/.qgis2/python/plugins/qgis2web/exp2js.py", line 39, in compile
    return exp2func(expstr, name, mapLib)
  File "/home/cernia/.qgis2/python/plugins/qgis2web/exp2js.py", line 49, in exp2func
    js = walkExpression(exp.rootNode(), mapLib=mapLib)
  File "/home/cernia/.qgis2/python/plugins/qgis2web/exp2js.py", line 72, in walkExpression
    jsExp = handle_binary(node, mapLib)
  File "/home/cernia/.qgis2/python/plugins/qgis2web/exp2js.py", line 128, in handle_binary
    op = node.op()
AttributeError: 'Node' object has no attribute 'op'
 */};