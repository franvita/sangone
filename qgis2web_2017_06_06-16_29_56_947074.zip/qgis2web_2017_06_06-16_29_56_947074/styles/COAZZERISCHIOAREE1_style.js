var size = 0;
function categories_COAZZERISCHIOAREE1(feature, value) {
                switch(value) {case 'R1':
                    return [ new ol.style.Style({
         fill: new ol.style.Fill({color: 'rgba(221,209,68,0.4)'})
    })];
                    break;
case 'R2':
                    return [ new ol.style.Style({
         fill: new ol.style.Fill({color: 'rgba(255,170,0,0.4)'})
    })];
                    break;
case 'R3':
                    return [ new ol.style.Style({
         fill: new ol.style.Fill({color: 'rgba(255,85,0,0.4)'})
    })];
                    break;
case 'R4':
                    return [ new ol.style.Style({
         fill: new ol.style.Fill({color: 'rgba(170,0,255,0.4)'})
    })];
                    break;}};
var styleCache_COAZZERISCHIOAREE1={}
var style_COAZZERISCHIOAREE1 = function(feature, resolution){
    var context = {
        feature: feature,
        variables: {}
    };
    var value = feature.get("ris");
    var style = categories_COAZZERISCHIOAREE1(feature, value);
    if ("" !== null) {
        var labelText = String("");
    } else {
        var labelText = ""
    }
    var key = value + "_" + labelText

    if (!styleCache_COAZZERISCHIOAREE1[key]){
        var text = new ol.style.Text({
              font: '10.725px \'Noto Sans\', sans-serif',
              text: labelText,
              textBaseline: "center",
              textAlign: "left",
              offsetX: 5,
              offsetY: 3,
              fill: new ol.style.Fill({
                color: 'rgba(0, 0, 0, 255)'
              }),
            });
        styleCache_COAZZERISCHIOAREE1[key] = new ol.style.Style({"text": text})
    }
    var allStyles = [styleCache_COAZZERISCHIOAREE1[key]];
    allStyles.push.apply(allStyles, style);
    return allStyles;
};